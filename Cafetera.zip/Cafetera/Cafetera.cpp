#include "Cafetera.h"

int main()
{
    Cafetera cafetera1 = Cafetera();
    Cafetera cafetera2 = Cafetera(1000);
    cafetera2.vaciarCafetera();

    return 0;
}